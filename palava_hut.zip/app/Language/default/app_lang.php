<?php

return [
    "project_inquiries" => "Project Inquiries",
];