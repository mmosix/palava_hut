<?php

return [
    "full_name" => "Full Name",
    "email_address" => "Email Address",
    "phone_number" => "Phone Number",
    "preferred_contact_method" => "Preferred Contact Method",
    "country_of_residence" => "Country of Residence",
    "property_purpose" => "Purpose of Property",
    "preferred_property_location" => "Preferred Property Location",
    "preferred_development" => "Preferred Development",
    "property_type" => "Property Type",
    "preferred_size" => "Preferred Size",
    "additional_features" => "Additional Features",
    "budget_range" => "Budget Range",
    "property_location" => "Property Location",
    "plot_size" => "Plot Size",
    "property_style" => "Property Style",
    "bedrooms_bathrooms" => "Number of Bedrooms/Bathrooms",
    "specific_features" => "Specific Features",
    "expected_timeline" => "Expected Timeline",
    "financing_interest" => "Interest in Financing",
    "additional_notes" => "Additional Notes"
];