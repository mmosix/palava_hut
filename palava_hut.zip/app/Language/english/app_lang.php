<?php

$lang["project_inquiry_form"] = "Project Inquiry Form";
$lang["project_inquiries"] = "Project Inquiries";
$lang["view_submissions"] = "View Submissions";
$lang["project_type"] = "Type of Project";
$lang["inquiry_type"] = "Inquiry Type";
$lang["project_inquiry_details"] = "Project Inquiry Details";
$lang["general_information"] = "General Information";
$lang["planned_development_details"] = "Planned Development Details";
$lang["custom_build_details"] = "Custom Build Details";
$lang["optional_information"] = "Optional Information";